<link rel="stylesheet" href="<?php echo e(asset('dist/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist/css/font-awesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist/css/bootstrap-datepicker.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist/css/bootstrap-timepicker.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist/css/bootstrap-tagsinput.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist/css/duotone-dark.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist/css/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist/css/iziToast.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist/css/fontawesome-iconpicker.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist/css/bootstrap4-toggle.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist/css/summernote-bs4.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist/css/components.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist/css/spacing.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist/css/custom.css')); ?>"><?php /**PATH C:\Users\63936\Documents\GitHub\LabasonSafeHaven\lsh_capstone\resources\views/customer/layout/styles.blade.php ENDPATH**/ ?>