<div class="main-sidebar">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand py-1">
            <a href="<?php echo e(route('customer_home')); ?>">
                <img src="<?php echo e(asset('uploads/logo.png')); ?>" alt="" class="logo py-1">
            </a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="<?php echo e(route('customer_home')); ?>"></a>
        </div>

        <ul class="sidebar-menu">

            <li class="<?php echo e(Request::is('customer/home') ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(route('customer_home')); ?>"><i class="fa fa-tachometer"></i> <span>Dashboard</span></a></li>

            <li class="<?php echo e(Request::is('customer/order/view') ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(route('customer_order_view')); ?>"><i class="fa fa-question-circle"></i> <span>Orders</span></a></li>


            

            

            
            

            
        </ul>
    </aside>
</div><?php /**PATH C:\Users\63936\Documents\GitHub\LabasonSafeHaven\lsh_capstone\resources\views/customer/layout/sidebar.blade.php ENDPATH**/ ?>