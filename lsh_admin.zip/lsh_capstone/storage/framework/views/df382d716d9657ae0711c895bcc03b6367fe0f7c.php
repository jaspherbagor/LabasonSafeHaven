

<?php $__env->startSection('content'); ?>

<div class="login-container container-fluid d-flex align-items-center justify-content-center px-2 py-5">
    <div class="g-3 needs-validation login-form-container p-3 my-5 h-auto">
        <div class="text-center">
            <a href="<?php echo e(route('home')); ?>">
                <img src="<?php echo e(asset('home_images/logo.png')); ?>" class="logo-img" alt="logo"/>
            </a>
        </div>
        <h2 class="my-4 text-center fw-bolder text-white">Login Account</h2>
        <?php if(Session::has('error')): ?>
        <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
        <?php endif; ?>
        <form action="" method="post" class="text-white"><?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-12 mb-3">
                    <label for="email">Email</label>
                    <input type="email" name="email" class="form-control">
                    <?php if($errors->has('email')): ?>
                    <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 mb-3">
                    <div class="col-md-12 mb-3">
                        <label for="password" class="form-label">Password</label>
                        <div class="d-flex">
                            <input type="password" name="password" class="form-control" id="password">
                            <span class="input-group-addon" id="togglePassword">
                                <i class="bi bi-eye position-absolute fs-4 mt-1" ></i>
                            </span>
                        </div>
                        <?php if($errors->has('password')): ?>
                        <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="text-center mt-2 mb-2">
                <button class="btn fs-5 px-3 py-2 login-btn text-black" type="submit" id="login">LOGIN</button>
            </div>

            <div class="text-center mt-4">
                <p class="text-white py-0 my-0">
                    Don't have an account yet?
                    <a href="<?php echo e(route('register')); ?>" class="text-decoration-none register-link fw-semibold">
                      Create  
                    </a>
                    an account.
                </p>
                <p class="py-0 my-0">
                    <a href="" class="text-decoration-none forgot-password-link">Forgot Password</a>
                </p>
            </div>
        </form>
        
    </div>
</div>

<script>
    let password = document.getElementById('password');
    let togglePassword = document.getElementById('togglePassword');
    togglePassword.addEventListener('click', function() {
        if(password.type === "password"){
            password.type = "text";
            togglePassword.innerHTML=`<i class="bi bi-eye-slash position-absolute fs-4 mt-1" ></i>`;
        } else {
            password.type = "password";
            togglePassword.innerHTML=`<i class="bi bi-eye position-absolute fs-4 mt-1" ></i>`;
        }
    })
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\63936\Documents\GitHub\LabasonSafeHaven\lsh_admin\resources\views/login.blade.php ENDPATH**/ ?>