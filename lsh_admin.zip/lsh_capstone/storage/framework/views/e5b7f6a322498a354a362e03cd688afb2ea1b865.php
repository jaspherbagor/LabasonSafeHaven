<!DOCTYPE html>
<html lang="en">
<head>
    <title>Email</title>
</head>
<body>
    <p><?php echo $body; ?></p>
</body>
</html><?php /**PATH C:\Users\63936\Documents\GitHub\LabasonSafeHaven\lsh_admin\resources\views/email/email.blade.php ENDPATH**/ ?>