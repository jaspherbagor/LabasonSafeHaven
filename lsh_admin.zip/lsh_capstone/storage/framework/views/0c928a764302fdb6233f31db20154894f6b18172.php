<?php $__env->startSection('nav'); ?>
    <nav class="navbar navbar-expand-lg container-fluid px-md-4 px-sm-4 px-2 py-2 position-absolute">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="<?php echo e(asset('home_images/logo.png')); ?>" alt="" class="logo">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link text-black me-3" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-black me-3" href="#">About</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-black me-3" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            Accommodation
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#">Hotel</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">Apartment</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">Boarding House</a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-black me-3" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            Gallery
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#">Photo Gallery</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">Video Gallery</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-black me-3" href="#">Blog</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-black me-3" href="#">Contact</a>
                    </li>
                </ul>
                <div class="d-flex ms-auto">
                    <a href="<?php echo e(route('login')); ?>" class="btn login-btn me-3">Login</a>
                    <a href="<?php echo e(route('register')); ?>" class="btn register-btn">Register</a>
                </div>
            </div>
        </div>
    </nav>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\63936\Documents\GitHub\LabasonSafeHaven\lsh_admin\resources\views/layout/nav.blade.php ENDPATH**/ ?>